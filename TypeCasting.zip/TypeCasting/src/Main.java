
public class Main {
    public static void main(String[] args) {
  //Type casting
        float myFloat=5;
        System.out.println(myFloat);
        int myInt=(int) 5.56f;
        System.out.println(myInt);
        float eDec=(float) 3.444;
        System.out.println(eDec);
        long eBig=(long) 3.4666786;
        System.out.println(eBig);
        int eInt=(int) 3.444;
        System.out.println(eInt);
    }
}

public class Main {
    public static void main(String[] args) {
        //Assignment Operator
        int a=5;
        int NewInt=7;
        System.out.println(a);
        System.out.println(NewInt);
        // Create a program swap two numbers
        System.out.println("Swap Two Numbers");
        int x=10;
        System.out.println("Before swap x is:"+x);
        int y=15;
        System.out.println("Before Swap Y is:"+y);
        x=x+y;
        y=x-y;
        x=x-y;
        System.out.println("After swap x is:"+x);
        System.out.println("After Swap y is:"+y);


    }
}
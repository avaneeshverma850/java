
public class Main {
    public static void main(String[] args) {
        System.out.println("good morning");
        System.out.println("subscribe");
        //problem 3
        //Right Half pyramid
        System.out.println("*");
        System.out.println("* *");
        System.out.println("* * *");
        System.out.println("* * * *");
        System.out.println("* * * * * *");
        //problem 4
        //Reverse Right Half Pyramid
        /*System.out.println("******");
        System.out.println("****");
        System.out.println("***");
        System.out.println("**");
        System.out.println("*");*/
        //problem 5
        //Left Half Pyramid
        /*System.out.println("    *");
        System.out.println("   **");
        System.out.println("  ***");
        System.out.println(" ****");
        System.out.println("*****");*/
    }
}

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello \"Avanesh\" ");
        System.out.println("Hello \\Avanesh");
        System.out.println("Hello \nAvanesh");
        System.out.println("Hello\tAvanesh");
        System.out.println("Hello\bAvanesh");
    }
}
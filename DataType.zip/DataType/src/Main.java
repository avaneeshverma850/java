
public class Main {
    public static void main(String[] args) {
        int a=4;
        int b=6;
        System.out.println(a);
        a=12;
        System.out.println(a);
        System.out.println(b);
        float myfloat=0.6f;
        double c=1.22;
        System.out.println(c);
        System.out.println(myfloat);
        String wishes="Good Morning";
        System.out.println(wishes);
        char myCharacter='A';
        System.out.println(myCharacter);
        
    }
}
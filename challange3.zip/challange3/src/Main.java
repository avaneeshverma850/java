import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //create two numbers and show result of all arithmetic operators
      Scanner sc=new Scanner(System.in);
        /*System.out.println("Welcome to arithmetic calculator");
        System.out.println("Please enter first number:");
        int a=sc.nextInt();
        System.out.println("Please enter second number:");
        int b=sc.nextInt();
        int add=a+b;
        int sub=a-b;
        int mul=a*b;
        int Div=a/b;
        int Mod=a%b;
        System.out.println("Addition:"+add);
        System.out.println("Subtraction:"+sub);
        System.out.println("Multiplication:"+mul);
        System.out.println("Division:"+Div);
        System.out.println("Modulus:"+Mod);*/
        //Product of two floating points numbers is
       /* System.out.println("Calculate product of two floating point ");
        System.out.println("Please enter first floating number:");
        double firstnum=sc.nextDouble();
        System.out.println("Please enter second floating number:");
        double secondnum=sc.nextDouble();
        double prod=firstnum*secondnum;
        System.out.println("Product of two floating number is:"+prod);*/
        //Perimeter of a rectangle
       /* System.out.println("Calculate Perimeter of Rectangle");
        System.out.println("Please enter length");
        int length=sc.nextInt();
        System.out.println("Please enter breadth");
        int breadth=sc.nextInt();
        int Perimeter=2*(length+breadth);
        System.out.println("Perimeter of rectangle is:"+Perimeter);*/
        //Calculate area of triangle
       /* System.out.println("Area of triangle");
        System.out.println("Please Enter height");
        double height=sc.nextDouble();
        System.out.println("Please enter base");
        double base=sc.nextDouble();
        double Area=(0.5*base*height);
        System.out.println("Area of triangle is:"+ Area);*/
        //Calculate simple interest
        /*System.out.println("Welcome to simple interest calculator");
        System.out.println("Please enter your principal amount Rs");
        int principal=sc.nextInt();
        System.out.println("Now tell me rate of Interest");
        float rate=sc.nextFloat();
        System.out.println("Now tell me how many year borrowing this money");
        float years=sc.nextFloat();
        float interest=(principal*rate*years)/100;
        System.out.println("Simple interest is: "+interest);*/
        //Calculate compound interest
        /*System.out.println("Welcome to calculate Compound interest calculator");
        System.out.println("Please enter your principal amount");
        int principal=sc.nextInt();
        System.out.println("Now tell me your rate of interest");
        float rate =sc.nextFloat();
        System.out.println("Now tell me how many year borrowing this money");
        float years=sc.nextFloat();

        double CI=principal*Math.pow((1 + rate/100) ,years);
        System.out.println("Compound interest is: "+CI);*/
        //program to convert fahrenheit to celsius
        System.out.println("Welcome to temperature converter");
        System.out.println("Enter your temp in f:");
        float fah=sc.nextFloat();
        float cel=(fah-32)*5.0f/9;
        System.out.println("Fahrenheit to celsius:"+cel);







    }
}
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        /*System.out.println("Enter Your Name:");
        String name=sc.nextLine();
        System.out.println("Welcome "+name);
        System.out.println("Please Enter your name:");
        String name1= sc.nextLine();
        System.out.println("Good Morning "+name1);
        System.out.println(name1 + ", Also tell me your age: ");
        int age=sc.nextInt();
        System.out.println("Your Age is:" + age);*/
        //Problem 1
        /*System.out.println("Enter your name:");
        String name=sc.nextLine();
        System.out.println("Welcome " + name +" to My Class");*/
        //Sum of two number
        System.out.println("Enter Two Number");
        System.out.println("Enter first number:");
        int a=sc.nextInt();
        System.out.println("Enter second number:");
        int b=sc.nextInt();
        int sum=a+b;
        System.out.println("Sum of Two number is:"+sum);

    }
}
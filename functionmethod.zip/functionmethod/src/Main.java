import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
      // System.out.println("In main method");
      // greetinguser();
        //System.out.println("Method calling completed");
      //  greetinguser();
      //  greetinguser();
     //   greetinguser();
     //   greetinguser();
     //   greetinguser();
      //  greetinguser();
      //  Hello();
      // printfirstpattern();
     //   printsecondpattern();
        //evenodd();
      /*  Scanner input=new Scanner(System.in);
        greetinguser();
        System.out.println("Welcome to calculator");
        System.out.println("Please enter the number:");
        int first=input.nextInt();
        System.out.println("Please enter the number");
        int second=input.nextInt();
        int sum=first+second;
        System.out.println("Sum of the number is:"+sum);*/
       // int num1=readnumber();
       // int num2=readnumber();
       // int sum=num2+num1;
       // System.out.println("Sum of the number is:"+sum);;
        System.out.println(sum(3,4));
        System.out.println(sum(3,5));
        System.out.println(sum(3,8));
        System.out.println(sum(3,9));
        System.out.println(sum(3,10));
    }

    public  static void greetinguser(){
        System.out.println("Good Morning From Avaneesh Verma");
    }
    public static void Hello(){
        System.out.println("Avaneesh Verma");
    }
    public static void printfirstpattern(){
        System.out.println("*\n* *\n* * *\n* * * *\n* * * * *");
    }
    public static void printsecondpattern(){
        System.out.println("**\n***\n***\n******");
    }
    public static void evenodd(){
        Scanner sc=new Scanner(System.in);
        System.out.println("Welcome to calculate evenodd number");
        int x= sc.nextInt();
        if(x%2==0)
            System.out.println("Even");
        else
            System.out.println("Odd");
    }
    public static int readnumber(){
        Scanner input=new Scanner(System.in);
        System.out.println("Please Enter the numbeer:");
        int number=input.nextInt();
        return number;
    }
    public static int sum(int a,int b){
        System.out.println("First number received:"+ a);
        System.out.println("Second number received:" +b);
        int sum=a+b;
        return sum;
    }

}

public class Main {
    public static void main(String[] args) {
        //Bitwise operator
        //problem 1
        System.out.println("Bitwise And operator  of two numbers");
        int x=12;
        int y=13;
        System.out.println(x&y);
        //problem 2
        System.out.println("Bitwise OR of two numbers");
        int a=13;
        int b=12;
        System.out.println(a|b);
        //problem 3
        System.out.println("Bitwise XOR of two numbers");
        int c=1;
        int d=2;
        System.out.println(c^d);
        //problem 4
        System.out.println("Bitwise compliment of a numbers ");
        int e=4;
        System.out.println(~e);
        //Problem 5
        System.out.println("Left shift operator");
        int num=4;
        System.out.println(num<<2);
        //Problem 6
        System.out.println("Right shift operator");
        int num1=4;
        System.out.println(num1>>1);
        //problem 7
        System.out.println("Calculate even or odd number using bitwise operator");
        if((4 & 1)==1)
            System.out.println("odd");
        else
            System.out.println("Even");







    }
}

public class Main {
    public static void main(String[] args) {
        // Show the following patterns using single print statement.
        //Right half pyramid
        System.out.println("Right Half Pyramid");
        System.out.println("*\n* *\n* * *\n* * * *\n* * * * * ");
        //Reverse right half pyramid
        System.out.println("Reverse Right Half Pyramid");
        System.out.println("* * * * *\n* * * *\n* * *\n* *\n*");
        //left half pyramid
        System.out.println("Left Half Pyramid");
        System.out.println("        *\n      * *\n    * * *\n  * * * *\n* * * * *");
    }
}
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        //Problem 1
       /* System.out.println("Welcome to Calculate positive ,negative or zero");
        System.out.println("Please enter your number");
        int number=sc.nextInt();
        if(number>0)
            System.out.println("Positive Number:"+ number);
        else if (number==0)
            System.out.println("Number is Zero:"+number);
        else
            System.out.println("Number is negative:"+number);*/
        //Problem 2

       /* System.out.println("Welcome to calculate even or odd number");
        System.out.println("Enter your number");
        int x=sc.nextInt();
        if(x%2==0)
            System.out.println("Even");
        else
            System.out.println("Odd");*/
        //Problem 3
        /*System.out.println("Calculate Greatest of three numbers");
        System.out.println("Enter first number");
        int x=sc.nextInt();
        System.out.println("Enter second number");
        int y=sc.nextInt();
        System.out.println("Enter third number");
        int z=sc.nextInt();
        if(x>y && x>z)
            System.out.println("Greatest number is x:" + x);
        else if(y>x &&y>z)
            System.out.println("Greatest number is y:" +y);
        else
            System.out.println("Greatest number is z:" +z);*/
        //Problem 4
       /* System.out.println("Calculate grades based on marks");
        System.out.println("Enter your percentage");
        float x=sc.nextFloat();
        if(x>90)
            System.out.println("Grade:A");
        else if(x<90 && x>75)
            System.out.println("Grade:B");
        else if(x<75 && x>60)
            System.out.println("Grade:C");
        else if( x<60 && x>30)
            System.out.println("Grade:D");
        else
            System.out.println("Fail");*/
        //Problem 5
       /* System.out.println("Welcome to calculate different age groups");
        System.out.println("Enter age of person");
        int age=sc.nextInt();
        if(age>60)
            System.out.println("Senior Citizen");
        else if(age<60 && age>20)
            System.out.println("Adult");
        else if(age<20 && age>13)
            System.out.println("Teen");
        else
            System.out.println("Child");*/
    }
}
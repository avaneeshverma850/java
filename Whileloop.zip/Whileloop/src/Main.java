import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //Loop
       /* System.out.println("Print Number from 1 to 10");
        int a=1;// initialization
        while(a<=10){ //condition
            System.out.println(a);//actual work
            a=a+1; //updating the condition
        }*
        */
        //problem 2
       /* int count=500;
        while(count>=200){
            System.out.println(count);
            count=count-1;
        }*/
        Scanner input=new Scanner(System.in);
        int i=0;
        while(i<5){
            int a=input.nextInt();
            System.out.println("Number is:"+ a);
            i=i+1;
        }
    }
}
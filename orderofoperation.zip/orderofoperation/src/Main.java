
public class Main {
    public static void main(String[] args) {
        //order of operation
        System.out.println(8-3*3);
        System.out.println(9/3*2/6);
        //If same operator are their then go from left to right
        System.out.println(9/3/3);
        System.out.println(9/(3/3 + 2));
    }
}